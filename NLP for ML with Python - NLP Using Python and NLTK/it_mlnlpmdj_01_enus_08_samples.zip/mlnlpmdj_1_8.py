# -*- coding: utf-8 -*-
"""
Created on Sun Jul 14 23:26:06 2019

@author: Welcome
"""


from nltk.tokenize import RegexpTokenizer
raw_tokens = RegexpTokenizer('\w+')
rawText=raw_tokens.tokenize('How are you today?.')
print(rawText)


from nltk.tokenize import word_tokenize

data="hello today it's raining! don't forget your umbrella"
word_tokens=word_tokenize(data)
print(word_tokens)


from nltk.tokenize import sent_tokenize
data="hello today it's raining! don't forget your umbrella."
sent_tokens=sent_tokenize(data)
print(sent_tokens)

from nltk.corpus import brown
print(brown.words())
print(brown.sents())






